package com.ithublive.vfresho.Models;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class CartInsertion {

// public static List<CartModel> cartProducts;
  public static Map<String,CartModel> cartAddedProducts;//=new HashMap<String,CartModel>();
  public static double cartprice;
}
